﻿namespace xClient.Enums
{
    public enum ShutdownAction
    {
        Shutdown,
        Restart,
        Standby
    }
}
