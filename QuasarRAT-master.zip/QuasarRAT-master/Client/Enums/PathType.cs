﻿namespace xClient.Enums
{
    public enum PathType
    {
        File,
        Directory,
        Back
    }
}
