﻿namespace xServer.Enums
{
    public enum UserStatus
    {
        Idle,
        Active
    }
}
